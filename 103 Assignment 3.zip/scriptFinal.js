/*
Create a calculator where you:

1) click on a button to trigger the calculator function,

2) get two numbers from the prompt,

3) display the result of the four operations (+, -, *, /) 
   in a specific div (getting the element by id).
*/


function getNumber(){
    num=parseInt(prompt("Enter number: "));
    return num;
}

function addition(){
    num1=getNumber();
    num2=getNumber();
    document.getElementById("result").innerHTML=num1 + num2;
    return num1+num2;
}

function subtraction(){
    num1=getNumber();
    document.write(`next`);
    num2=getNumber();    
    document.getElementById("result").innerHTML=num1 - num2;
    return num1-num2;
}

function multiplication(){
    num1=getNumber();
    num2=getNumber();    
    document.getElementById("result").innerHTML=num1 * num2;
    return num1*num2;
}

function division(){
    num1=getNumber();
    num2=getNumber();    
    document.getElementById("result").innerHTML=num1 / num2;
    return num1/num2;
}






